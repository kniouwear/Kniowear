# KNIO Fashion Brand Website

A premium, modern fashion brand website built with Next.js App Router, PostgreSQL, and Drizzle ORM.

## Features

- Luxury black-and-white fashion landing page
- Collections, About, and Contact pages
- Newsletter subscription form
- Contact form with PostgreSQL storage
- Admin dashboard for managing:
  - Products
  - Brand settings
  - Newsletter subscribers
  - Contact messages
- Responsive design with motion and editorial styling

## Admin Access

- Login page: `/admin/login`
- Default password: `knio-admin`
- You can override it with the `ADMIN_PASSWORD` environment variable.

## Environment Variables

Create a `.env` file based on `.env.example`:

- `DATABASE_URL` — PostgreSQL connection string
- `ADMIN_PASSWORD` — password for the admin dashboard

## Development

```bash
npm install
npm run dev
```

## Database

This project uses Drizzle ORM. If you change the schema, push it to the database with:

```bash
npx drizzle-kit push
```

## Build

```bash
npm run build
```

## Admin URLs

- Website: `/`
- Admin dashboard: `/admin`
- Admin login: `/admin/login`

## Notes

- The site is ready for `kniowear.com`
- Hero and brand content can be managed from the admin dashboard
- Products added in the dashboard appear automatically on the homepage and collections page
