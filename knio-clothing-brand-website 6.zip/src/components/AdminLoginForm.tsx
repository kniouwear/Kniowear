"use client";

import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";

export default function AdminLoginForm() {
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");

    const res = await fetch("/api/admin/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password }),
    });

    const data = await res.json();
    setLoading(false);

    if (res.ok) {
      router.push("/admin");
      router.refresh();
      return;
    }

    setError(data.error || "Login failed");
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <input
        type="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        placeholder="Admin password"
        className="w-full bg-transparent border border-white/15 px-5 py-4 text-sm text-white placeholder:text-white/25 focus:outline-none focus:border-white/50"
        required
      />
      <button
        type="submit"
        disabled={loading}
        className="w-full bg-white text-black px-6 py-4 text-[13px] font-medium tracking-wide-custom uppercase hover:bg-white/90 transition-colors disabled:opacity-50"
      >
        {loading ? "Signing in..." : "Enter Dashboard"}
      </button>
      {error ? <p className="text-sm text-red-400">{error}</p> : null}
    </form>
  );
}
