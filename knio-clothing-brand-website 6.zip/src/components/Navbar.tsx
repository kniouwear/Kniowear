"use client";

import Link from "next/link";
import { useState } from "react";

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-md border-b border-white/5">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link href="/" className="relative group">
            <span className="text-2xl font-bold tracking-ultra uppercase">
              KNIO
            </span>
            <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-white transition-all duration-500 group-hover:w-full" />
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-10">
            {[
              { href: "/", label: "Home" },
              { href: "/collections", label: "Collections" },
              { href: "/about", label: "About" },
              { href: "/contact", label: "Contact" },
            ].map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="relative text-[13px] font-light tracking-wide-custom uppercase text-white/70 hover:text-white transition-colors duration-300 group"
              >
                {link.label}
                <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-white transition-all duration-500 group-hover:w-full" />
              </Link>
            ))}
          </div>

          {/* CTA */}
          <div className="hidden md:flex items-center gap-6">
            <a
              href="https://kniowear.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[13px] font-medium tracking-wide-custom uppercase bg-white text-black px-6 py-2.5 hover:bg-white/90 transition-colors duration-300"
            >
              Shop Now
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden relative w-8 h-8 flex flex-col items-center justify-center gap-1.5"
            aria-label="Toggle menu"
          >
            <span
              className={`w-6 h-[1px] bg-white transition-all duration-300 ${
                isOpen ? "rotate-45 translate-y-[4px]" : ""
              }`}
            />
            <span
              className={`w-6 h-[1px] bg-white transition-all duration-300 ${
                isOpen ? "-rotate-45 -translate-y-[3px]" : ""
              }`}
            />
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div
        className={`md:hidden overflow-hidden transition-all duration-500 ${
          isOpen ? "max-h-[400px] opacity-100" : "max-h-0 opacity-0"
        }`}
      >
        <div className="px-6 py-8 bg-black/95 border-t border-white/5 flex flex-col gap-6">
          {[
            { href: "/", label: "Home" },
            { href: "/collections", label: "Collections" },
            { href: "/about", label: "About" },
            { href: "/contact", label: "Contact" },
          ].map((link) => (
            <Link
              key={link.href}
              href={link.href}
              onClick={() => setIsOpen(false)}
              className="text-lg font-light tracking-wide-custom uppercase text-white/80 hover:text-white transition-colors"
            >
              {link.label}
            </Link>
          ))}
          <a
            href="https://kniowear.com"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block text-center text-sm font-medium tracking-wide-custom uppercase bg-white text-black px-6 py-3 mt-2"
          >
            Shop Now
          </a>
        </div>
      </div>
    </nav>
  );
}
