"use client";

import { useState, type ChangeEvent, type FormEvent } from "react";

export default function ContactForm() {
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [responseMsg, setResponseMsg] = useState("");

  function handleChange(e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) {
    setForm({ ...form, [e.target.name]: e.target.value });
    if (status !== "idle") setStatus("idle");
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setStatus("loading");
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (res.ok) {
        setStatus("success");
        setResponseMsg(data.message);
        setForm({ name: "", email: "", subject: "", message: "" });
      } else {
        setStatus("error");
        setResponseMsg(data.error);
      }
    } catch {
      setStatus("error");
      setResponseMsg("Network error. Please try again.");
    }
  }

  const inputClasses =
    "w-full bg-transparent border border-white/15 px-5 py-4 text-sm text-white placeholder:text-white/25 focus:outline-none focus:border-white/50 transition-colors duration-300";

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
        <input
          type="text"
          name="name"
          value={form.name}
          onChange={handleChange}
          placeholder="Your Name"
          required
          className={inputClasses}
        />
        <input
          type="email"
          name="email"
          value={form.email}
          onChange={handleChange}
          placeholder="Your Email"
          required
          className={inputClasses}
        />
      </div>
      <select
        name="subject"
        value={form.subject}
        onChange={handleChange}
        required
        className={`${inputClasses} ${!form.subject ? "text-white/25" : ""}`}
      >
        <option value="" disabled>
          Select a Subject
        </option>
        <option value="General Inquiry">General Inquiry</option>
        <option value="Order Support">Order Support</option>
        <option value="Collaboration">Collaboration</option>
        <option value="Press & Media">Press &amp; Media</option>
        <option value="Other">Other</option>
      </select>
      <textarea
        name="message"
        value={form.message}
        onChange={handleChange}
        placeholder="Your Message"
        required
        rows={6}
        className={`${inputClasses} resize-none`}
      />
      <button
        type="submit"
        disabled={status === "loading"}
        className="w-full sm:w-auto bg-white text-black px-12 py-4 text-[13px] font-medium tracking-wide-custom uppercase hover:bg-white/90 transition-colors duration-300 disabled:opacity-50"
      >
        {status === "loading" ? "Sending..." : "Send Message"}
      </button>

      {status === "success" && (
        <p className="text-sm text-green-400 mt-2">{responseMsg}</p>
      )}
      {status === "error" && (
        <p className="text-sm text-red-400 mt-2">{responseMsg}</p>
      )}
    </form>
  );
}
