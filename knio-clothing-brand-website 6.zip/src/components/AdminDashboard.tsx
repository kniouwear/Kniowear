"use client";

import { useMemo, useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";

interface Product {
  id: number;
  name: string;
  slug: string;
  description: string;
  price: number;
  category: string;
  imageUrl: string;
  featured: boolean;
  createdAt: string;
}

interface Subscriber {
  id: number;
  email: string;
  createdAt: string;
}

interface Message {
  id: number;
  name: string;
  email: string;
  subject: string;
  message: string;
  read: boolean;
  createdAt: string;
}

interface Setting {
  id: number;
  key: string;
  value: string;
  updatedAt: string;
}

interface AdminDashboardProps {
  products: Product[];
  subscribers: Subscriber[];
  messages: Message[];
  settings: Setting[];
}

const settingKeys = [
  "name",
  "domain",
  "tagline",
  "heroBadge",
  "heroTitle",
  "heroDescription",
  "newsletterTitle",
  "newsletterDescription",
];

export default function AdminDashboard({ products: initialProducts, subscribers, messages, settings }: AdminDashboardProps) {
  const router = useRouter();
  const [products, setProducts] = useState(initialProducts);
  const [savingSettings, setSavingSettings] = useState(false);
  const [savingProduct, setSavingProduct] = useState(false);
  const [status, setStatus] = useState("");
  const [settingsForm, setSettingsForm] = useState<Record<string, string>>(() => {
    const next = Object.fromEntries(settingKeys.map((key) => [key, ""])) as Record<string, string>;
    settings.forEach((setting) => {
      next[setting.key] = setting.value;
    });
    return next;
  });
  const [productForm, setProductForm] = useState({
    name: "",
    slug: "",
    description: "",
    price: "",
    category: "",
    imageUrl: "",
    featured: true,
  });

  const stats = useMemo(
    () => [
      { label: "Products", value: products.length },
      { label: "Subscribers", value: subscribers.length },
      { label: "Messages", value: messages.length },
      { label: "Unread", value: messages.filter((m) => !m.read).length },
    ],
    [messages, products.length, subscribers.length]
  );

  async function handleLogout() {
    await fetch("/api/admin/logout", { method: "POST" });
    router.push("/admin/login");
    router.refresh();
  }

  async function saveSettings() {
    setSavingSettings(true);
    setStatus("");
    const res = await fetch("/api/admin/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(settingsForm),
    });
    const data = await res.json();
    setSavingSettings(false);
    setStatus(res.ok ? data.message : data.error);
    if (res.ok) router.refresh();
  }

  async function createProduct(e: FormEvent) {
    e.preventDefault();
    setSavingProduct(true);
    setStatus("");
    const res = await fetch("/api/admin/products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(productForm),
    });
    const data = await res.json();
    setSavingProduct(false);
    if (res.ok) {
      setProducts((prev) => [data.product, ...prev]);
      setProductForm({ name: "", slug: "", description: "", price: "", category: "", imageUrl: "", featured: true });
      setStatus("Product added");
      router.refresh();
    } else {
      setStatus(data.error || "Failed to add product");
    }
  }

  async function toggleFeatured(product: Product) {
    const res = await fetch(`/api/admin/products/${product.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ featured: !product.featured }),
    });
    const data = await res.json();
    if (res.ok) {
      setProducts((prev) => prev.map((item) => (item.id === product.id ? data.product : item)));
      router.refresh();
    }
  }

  async function deleteProduct(id: number) {
    if (!confirm("Delete this product?")) return;
    const res = await fetch(`/api/admin/products/${id}`, { method: "DELETE" });
    if (res.ok) {
      setProducts((prev) => prev.filter((item) => item.id !== id));
      router.refresh();
    }
  }

  async function markMessageRead(id: number, read: boolean) {
    const res = await fetch(`/api/admin/messages/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ read }),
    });
    if (res.ok) router.refresh();
  }

  async function deleteMessage(id: number) {
    if (!confirm("Delete this message?")) return;
    const res = await fetch(`/api/admin/messages/${id}`, { method: "DELETE" });
    if (res.ok) router.refresh();
  }

  return (
    <main className="min-h-screen bg-black text-white">
      <header className="border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 lg:px-10 py-6 flex flex-col sm:flex-row gap-4 sm:items-center sm:justify-between">
          <div>
            <p className="text-[11px] tracking-ultra uppercase text-white/40">KNIO Admin</p>
            <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
          </div>
          <div className="flex gap-3">
            <a href="/" className="px-4 py-2 border border-white/10 text-sm text-white/70 hover:text-white transition-colors">View Site</a>
            <button onClick={handleLogout} className="px-4 py-2 bg-white text-black text-sm font-medium">Logout</button>
          </div>
        </div>
      </header>

      <section className="max-w-7xl mx-auto px-6 lg:px-10 py-10">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
          {stats.map((stat) => (
            <div key={stat.label} className="border border-white/10 p-5 bg-white/[0.02]">
              <p className="text-white/40 text-[11px] tracking-ultra uppercase mb-2">{stat.label}</p>
              <p className="text-3xl font-bold">{stat.value}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-10">
          <div className="border border-white/10 p-6 bg-white/[0.02]">
            <h2 className="text-xl font-semibold mb-4">Brand Settings</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {settingKeys.map((key) => (
                <label key={key} className="block">
                  <span className="block text-[11px] uppercase tracking-ultra text-white/40 mb-2">{key}</span>
                  {key.toLowerCase().includes("description") ? (
                    <textarea
                      value={settingsForm[key] || ""}
                      onChange={(e) => setSettingsForm((prev) => ({ ...prev, [key]: e.target.value }))}
                      className="w-full bg-transparent border border-white/10 px-4 py-3 text-sm min-h-28"
                    />
                  ) : (
                    <input
                      value={settingsForm[key] || ""}
                      onChange={(e) => setSettingsForm((prev) => ({ ...prev, [key]: e.target.value }))}
                      className="w-full bg-transparent border border-white/10 px-4 py-3 text-sm"
                    />
                  )}
                </label>
              ))}
            </div>
            <button onClick={saveSettings} disabled={savingSettings} className="mt-5 bg-white text-black px-5 py-3 text-sm font-medium disabled:opacity-50">
              {savingSettings ? "Saving..." : "Save Settings"}
            </button>
          </div>

          <div className="border border-white/10 p-6 bg-white/[0.02]">
            <h2 className="text-xl font-semibold mb-4">Add Product</h2>
            <form onSubmit={createProduct} className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input className="bg-transparent border border-white/10 px-4 py-3 text-sm" placeholder="Name" value={productForm.name} onChange={(e) => setProductForm({ ...productForm, name: e.target.value })} required />
              <input className="bg-transparent border border-white/10 px-4 py-3 text-sm" placeholder="Slug" value={productForm.slug} onChange={(e) => setProductForm({ ...productForm, slug: e.target.value })} required />
              <input className="bg-transparent border border-white/10 px-4 py-3 text-sm md:col-span-2" placeholder="Description" value={productForm.description} onChange={(e) => setProductForm({ ...productForm, description: e.target.value })} required />
              <input className="bg-transparent border border-white/10 px-4 py-3 text-sm" placeholder="Price" type="number" value={productForm.price} onChange={(e) => setProductForm({ ...productForm, price: e.target.value })} required />
              <input className="bg-transparent border border-white/10 px-4 py-3 text-sm" placeholder="Category" value={productForm.category} onChange={(e) => setProductForm({ ...productForm, category: e.target.value })} required />
              <input className="bg-transparent border border-white/10 px-4 py-3 text-sm md:col-span-2" placeholder="Image URL" value={productForm.imageUrl} onChange={(e) => setProductForm({ ...productForm, imageUrl: e.target.value })} required />
              <label className="flex items-center gap-2 text-sm text-white/70 md:col-span-2">
                <input type="checkbox" checked={productForm.featured} onChange={(e) => setProductForm({ ...productForm, featured: e.target.checked })} />
                Featured
              </label>
              <button disabled={savingProduct} className="bg-white text-black px-5 py-3 text-sm font-medium md:col-span-2 disabled:opacity-50">
                {savingProduct ? "Creating..." : "Create Product"}
              </button>
            </form>
          </div>
        </div>

        {status ? <p className="mb-6 text-sm text-white/60">{status}</p> : null}

        <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 mb-10">
          <div className="border border-white/10 p-6 bg-white/[0.02]">
            <h2 className="text-xl font-semibold mb-4">Products</h2>
            <div className="space-y-4 max-h-[600px] overflow-auto pr-2">
              {products.map((product) => (
                <div key={product.id} className="flex gap-4 border border-white/10 p-4">
                  <img src={product.imageUrl} alt={product.name} className="w-20 h-24 object-cover" />
                  <div className="flex-1">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <p className="font-semibold">{product.name}</p>
                        <p className="text-sm text-white/40">{product.category} · €{product.price}</p>
                        <p className="text-xs text-white/30 mt-1">{product.slug}</p>
                      </div>
                      <span className={`text-[10px] uppercase tracking-ultra ${product.featured ? "text-green-400" : "text-white/30"}`}>{product.featured ? "Featured" : "Regular"}</span>
                    </div>
                    <p className="text-sm text-white/50 mt-3 line-clamp-2">{product.description}</p>
                    <div className="flex gap-2 mt-4">
                      <button onClick={() => toggleFeatured(product)} className="px-3 py-2 text-xs border border-white/10">Toggle Featured</button>
                      <button onClick={() => deleteProduct(product.id)} className="px-3 py-2 text-xs border border-red-500/30 text-red-300">Delete</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-8">
            <div className="border border-white/10 p-6 bg-white/[0.02]">
              <h2 className="text-xl font-semibold mb-4">Subscribers</h2>
              <div className="space-y-3 max-h-[300px] overflow-auto pr-2">
                {subscribers.length === 0 ? <p className="text-white/40 text-sm">No subscribers yet.</p> : subscribers.map((item) => (
                  <div key={item.id} className="flex items-center justify-between border-b border-white/5 pb-3">
                    <span>{item.email}</span>
                    <span className="text-xs text-white/30">#{item.id}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="border border-white/10 p-6 bg-white/[0.02]">
              <h2 className="text-xl font-semibold mb-4">Messages</h2>
              <div className="space-y-4 max-h-[420px] overflow-auto pr-2">
                {messages.length === 0 ? <p className="text-white/40 text-sm">No messages yet.</p> : messages.map((message) => (
                  <div key={message.id} className={`border p-4 ${message.read ? "border-white/10 bg-white/[0.02]" : "border-white/20 bg-white/[0.03]"}`}>
                    <div className="flex items-start justify-between gap-4 mb-3">
                      <div>
                        <p className="font-semibold">{message.name}</p>
                        <p className="text-sm text-white/40">{message.email}</p>
                        <p className="text-xs uppercase tracking-ultra text-white/30 mt-1">{message.subject}</p>
                      </div>
                      <span className={`text-[10px] uppercase tracking-ultra ${message.read ? "text-white/30" : "text-yellow-300"}`}>{message.read ? "Read" : "Unread"}</span>
                    </div>
                    <p className="text-sm text-white/50 mb-4 whitespace-pre-wrap">{message.message}</p>
                    <div className="flex gap-2">
                      {!message.read ? <button onClick={() => markMessageRead(message.id, true)} className="px-3 py-2 text-xs border border-white/10">Mark Read</button> : null}
                      <button onClick={() => deleteMessage(message.id)} className="px-3 py-2 text-xs border border-red-500/30 text-red-300">Delete</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="border border-white/10 p-6 bg-white/[0.02]">
          <h2 className="text-xl font-semibold mb-4">Quick Notes</h2>
          <ul className="space-y-2 text-sm text-white/60">
            <li>• You can add/edit products and feature them in the collections section.</li>
            <li>• Brand copy can be updated from the settings form.</li>
            <li>• Contact messages and newsletter subscribers are stored in PostgreSQL.</li>
          </ul>
        </div>
      </section>
    </main>
  );
}
