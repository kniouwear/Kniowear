import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import ContactForm from "@/components/ContactForm";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Contact — KNIO",
  description: "Get in touch with KNIO. We'd love to hear from you — questions, collaborations, or just to say hello.",
};

export default function ContactPage() {
  return (
    <>
      <Navbar />

      {/* Hero */}
      <section className="pt-32 pb-12 px-6 lg:px-10">
        <div className="max-w-7xl mx-auto">
          <p className="text-[11px] font-light tracking-ultra uppercase text-white/40 mb-4">
            Get in Touch
          </p>
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold tracking-tight">
            Contact
          </h1>
          <p className="mt-6 text-lg font-light text-white/50 max-w-lg">
            Have a question, idea, or collaboration in mind? We&apos;d love to hear from you.
          </p>
        </div>
      </section>

      {/* Content */}
      <section className="py-20 px-6 lg:px-10">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-20">
            {/* Contact Info */}
            <div className="lg:col-span-1 space-y-12">
              <div>
                <h3 className="text-[11px] font-semibold tracking-ultra uppercase text-white/30 mb-4">
                  Email
                </h3>
                <p className="text-lg font-light">info@kniowear.com</p>
              </div>

              <div>
                <h3 className="text-[11px] font-semibold tracking-ultra uppercase text-white/30 mb-4">
                  Website
                </h3>
                <a
                  href="https://kniowear.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-lg font-light hover:text-white/70 transition-colors"
                >
                  kniowear.com
                </a>
              </div>

              <div>
                <h3 className="text-[11px] font-semibold tracking-ultra uppercase text-white/30 mb-4">
                  Follow Us
                </h3>
                <div className="space-y-3">
                  {["Instagram", "Twitter / X", "TikTok"].map((platform) => (
                    <a
                      key={platform}
                      href="#"
                      className="block text-base font-light text-white/50 hover:text-white transition-colors"
                    >
                      {platform}
                    </a>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-[11px] font-semibold tracking-ultra uppercase text-white/30 mb-4">
                  For Press & Media
                </h3>
                <p className="text-sm font-light text-white/50 leading-relaxed">
                  For press inquiries, media kits, and collaboration requests, 
                  please use the contact form or email us directly.
                </p>
              </div>
            </div>

            {/* Contact Form */}
            <div className="lg:col-span-2">
              <div className="border border-white/10 p-8 md:p-12">
                <h2 className="text-2xl font-bold tracking-tight mb-2">Send us a message</h2>
                <p className="text-sm font-light text-white/40 mb-10">
                  Fill out the form below and we&apos;ll get back to you within 24 hours.
                </p>
                <ContactForm />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-32 px-6 lg:px-10 bg-white/[0.02]">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-16">
            <p className="text-[11px] font-light tracking-ultra uppercase text-white/40 mb-4">
              Frequently Asked
            </p>
            <h2 className="text-4xl font-bold tracking-tight">FAQ</h2>
          </div>

          <div className="space-y-0">
            {[
              {
                q: "What are the shipping times?",
                a: "We ship worldwide. Standard delivery takes 5-7 business days. Express shipping is available at checkout for 2-3 business days.",
              },
              {
                q: "What is your return policy?",
                a: "We offer a 30-day hassle-free return policy. Items must be in original condition with tags attached. Visit kniowear.com for full details.",
              },
              {
                q: "How do I find my size?",
                a: "Each product page on kniowear.com includes a detailed size guide. If you're between sizes, we generally recommend sizing up for a relaxed fit.",
              },
              {
                q: "Do you offer collaborations?",
                a: "Yes! We love working with creators, artists, and brands that share our vision. Please reach out through the contact form above.",
              },
              {
                q: "Where are KNIO products made?",
                a: "Our garments are designed in-house and produced by carefully selected manufacturing partners who share our commitment to quality and ethical practices.",
              },
            ].map((faq) => (
              <div key={faq.q} className="border-b border-white/10 py-8">
                <h3 className="text-base font-medium mb-3">{faq.q}</h3>
                <p className="text-sm font-light text-white/40 leading-relaxed">
                  {faq.a}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </>
  );
}
