import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "About — KNIO",
  description: "The story behind KNIO. Learn about our mission, values, and the vision that drives every piece we create.",
};

const values = [
  {
    title: "Minimalism",
    description: "We believe in the power of less. Every design element serves a purpose, every detail is intentional.",
    icon: (
      <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={0.8}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6z" />
      </svg>
    ),
  },
  {
    title: "Quality",
    description: "Premium materials, expert craftsmanship. Each piece is made to stand the test of time and wear.",
    icon: (
      <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={0.8}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
      </svg>
    ),
  },
  {
    title: "Expression",
    description: "Fashion is personal. We create pieces that let you express who you are without saying a word.",
    icon: (
      <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={0.8}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01" />
      </svg>
    ),
  },
  {
    title: "Sustainability",
    description: "Responsible fashion is our commitment. Ethical sourcing, sustainable practices, mindful production.",
    icon: (
      <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={0.8}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
    ),
  },
];

const timeline = [
  { year: "2021", event: "KNIO founded with a vision to blend minimalism and bold fashion" },
  { year: "2022", event: "First collection launched — 'Origins' receives critical acclaim" },
  { year: "2023", event: "Expanded to 20+ countries, launched Streetwear line" },
  { year: "2024", event: "Noir collection debuts at fashion week, global recognition" },
  { year: "2025", event: "Avant-Garde collection pushes creative boundaries" },
  { year: "2026", event: "New era — FW26 collection, kniowear.com relaunch" },
];

export default function AboutPage() {
  return (
    <>
      <Navbar />

      {/* Hero */}
      <section className="relative min-h-[80vh] flex items-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/20235870/pexels-photo-20235870.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1600"
            alt="KNIO About"
            className="w-full h-full object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-black/40" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-10 pt-20">
          <p className="text-[11px] font-light tracking-ultra uppercase text-white/40 mb-6">
            Our Story
          </p>
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold tracking-tight leading-[0.95]">
            Born from
            <br />
            <span className="text-white/40">the desire</span>
            <br />
            to be different.
          </h1>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-32 px-6 lg:px-10">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-start">
            <div>
              <p className="text-[11px] font-light tracking-ultra uppercase text-white/40 mb-6">
                The Beginning
              </p>
              <h2 className="text-3xl md:text-4xl font-bold tracking-tight mb-8 leading-tight">
                KNIO started as a question: what if clothing could be both minimal and bold?
              </h2>
              <div className="space-y-6 text-base font-light text-white/50 leading-relaxed">
                <p>
                  In a world of fast fashion and fleeting trends, we wanted to create something 
                  different. Something that respects the individual, honors quality materials, 
                  and speaks through design rather than logos.
                </p>
                <p>
                  Every KNIO piece begins with a feeling — the confidence of wearing something 
                  that truly fits who you are. From there, our designers work to translate that 
                  feeling into fabric, form, and function.
                </p>
                <p>
                  Today, KNIO serves fashion-forward individuals across 50+ countries, 
                  but our mission remains the same: to create clothing that lets you 
                  express yourself without compromise.
                </p>
              </div>
            </div>

            <div className="relative">
              <div className="aspect-[4/5] overflow-hidden">
                <img
                  src="https://images.pexels.com/photos/7871152/pexels-photo-7871152.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700"
                  alt="KNIO brand story"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -left-6 bg-white text-black p-8 max-w-[200px]">
                <p className="text-3xl font-bold">2021</p>
                <p className="text-[11px] tracking-ultra uppercase mt-1 text-black/50">Founded</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-32 px-6 lg:px-10 bg-white/[0.02]">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20">
            <p className="text-[11px] font-light tracking-ultra uppercase text-white/40 mb-4">
              What We Stand For
            </p>
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight">Our Values</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
            {values.map((value) => (
              <div key={value.title} className="text-center group">
                <div className="text-white/30 group-hover:text-white transition-colors duration-500 mb-6 flex justify-center">
                  {value.icon}
                </div>
                <h3 className="text-lg font-semibold tracking-wide mb-3">{value.title}</h3>
                <p className="text-sm font-light text-white/40 leading-relaxed">
                  {value.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-32 px-6 lg:px-10">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-20">
            <p className="text-[11px] font-light tracking-ultra uppercase text-white/40 mb-4">
              Our Journey
            </p>
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight">Timeline</h2>
          </div>

          <div className="relative">
            {/* Line */}
            <div className="absolute left-[23px] top-0 bottom-0 w-[1px] bg-white/10" />

            <div className="space-y-12">
              {timeline.map((item) => (
                <div key={item.year} className="flex gap-8 items-start group">
                  <div className="relative flex-shrink-0">
                    <div className="w-12 h-12 border border-white/20 group-hover:border-white flex items-center justify-center transition-colors duration-500">
                      <div className="w-2 h-2 bg-white/30 group-hover:bg-white transition-colors duration-500" />
                    </div>
                  </div>
                  <div className="pt-2">
                    <p className="text-2xl font-bold mb-2">{item.year}</p>
                    <p className="text-sm font-light text-white/50 leading-relaxed">
                      {item.event}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Quote Section */}
      <section className="py-32 px-6 lg:px-10 border-y border-white/10">
        <div className="max-w-4xl mx-auto text-center">
          <svg className="w-10 h-10 mx-auto text-white/20 mb-8" fill="currentColor" viewBox="0 0 24 24">
            <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z" />
          </svg>
          <blockquote className="text-3xl md:text-4xl font-light leading-relaxed tracking-tight">
            &ldquo;We don&apos;t follow trends. We create a language of style that speaks to 
            the individual — bold, minimal, and unapologetically authentic.&rdquo;
          </blockquote>
          <p className="mt-8 text-[11px] tracking-ultra uppercase text-white/40">
            KNIO Design Team
          </p>
        </div>
      </section>

      {/* CTA */}
      <section className="py-32 px-6 text-center">
        <h2 className="text-4xl md:text-5xl font-bold tracking-tight mb-6">
          Join the movement.
        </h2>
        <p className="text-base font-light text-white/50 mb-10 max-w-md mx-auto">
          Discover what KNIO can do for your wardrobe.
        </p>
        <a
          href="https://kniowear.com"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-block bg-white text-black px-12 py-4 text-[13px] font-medium tracking-wide-custom uppercase hover:bg-white/90 transition-colors duration-300"
        >
          Shop at kniowear.com
        </a>
      </section>

      <Footer />
    </>
  );
}
