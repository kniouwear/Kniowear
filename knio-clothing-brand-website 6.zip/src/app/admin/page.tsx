import { db } from "@/db";
import { contactMessages, products, siteSettings, subscribers } from "@/db/schema";
import { defaultProducts, brandDefaults } from "@/lib/brand";
import { requireAdmin } from "@/lib/admin";
import { desc } from "drizzle-orm";
import AdminDashboard from "@/components/AdminDashboard";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  await requireAdmin();

  let [productRows, subscriberRows, messageRows, settingsRows] = await Promise.all([
    db.select().from(products).orderBy(desc(products.createdAt)),
    db.select().from(subscribers).orderBy(desc(subscribers.createdAt)),
    db.select().from(contactMessages).orderBy(desc(contactMessages.createdAt)),
    db.select().from(siteSettings),
  ]);

  if (productRows.length === 0) {
    await db.insert(products).values(defaultProducts);
    productRows = await db.select().from(products).orderBy(desc(products.createdAt));
  }

  if (settingsRows.length === 0) {
    await db.insert(siteSettings).values(
      Object.entries(brandDefaults).map(([key, value]) => ({ key, value }))
    );
    settingsRows = await db.select().from(siteSettings);
  }

  const serializeDate = (value: Date) => value.toISOString();

  const serializeProducts = (rows: typeof productRows) =>
    rows.map((row) => ({ ...row, createdAt: serializeDate(row.createdAt) }));
  const serializeSubscribers = (rows: typeof subscriberRows) =>
    rows.map((row) => ({ ...row, createdAt: serializeDate(row.createdAt) }));
  const serializeMessages = (rows: typeof messageRows) =>
    rows.map((row) => ({ ...row, createdAt: serializeDate(row.createdAt) }));
  const serializeSettings = (rows: typeof settingsRows) =>
    rows.map((row) => ({ ...row, updatedAt: serializeDate(row.updatedAt) }));

  return (
    <AdminDashboard
      products={serializeProducts(productRows)}
      subscribers={serializeSubscribers(subscriberRows)}
      messages={serializeMessages(messageRows)}
      settings={serializeSettings(settingsRows)}
    />
  );
}
