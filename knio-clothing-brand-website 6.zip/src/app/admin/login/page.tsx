import AdminLoginForm from "@/components/AdminLoginForm";

export const dynamic = "force-dynamic";

export default function AdminLoginPage() {
  return (
    <main className="min-h-screen bg-black text-white grid place-items-center px-6 py-12">
      <div className="w-full max-w-md border border-white/10 bg-white/[0.02] p-8">
        <p className="text-[11px] tracking-ultra uppercase text-white/40 mb-3">KNIO Admin</p>
        <h1 className="text-3xl font-bold mb-3">Sign in</h1>
        <p className="text-sm text-white/50 mb-8">Access the dashboard to manage products, settings, subscribers, and messages.</p>
        <AdminLoginForm />
      </div>
    </main>
  );
}
