import { db } from "@/db";
import { products } from "@/db/schema";
import { ADMIN_COOKIE } from "@/lib/admin";
import { NextRequest, NextResponse } from "next/server";

function isAuthed(req: NextRequest) {
  return req.cookies.get(ADMIN_COOKIE)?.value === "1";
}

export async function GET(req: NextRequest) {
  if (!isAuthed(req)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const items = await db.select().from(products).orderBy(products.createdAt);
  return NextResponse.json({ products: items });
}

export async function POST(req: NextRequest) {
  if (!isAuthed(req)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await req.json().catch(() => ({}));
  const { name, slug, description, price, category, imageUrl, featured } = body;

  if (!name || !slug || !description || !price || !category || !imageUrl) {
    return NextResponse.json({ error: "All fields are required" }, { status: 400 });
  }

  const inserted = await db.insert(products).values({
    name,
    slug,
    description,
    price: Number(price),
    category,
    imageUrl,
    featured: Boolean(featured),
  }).returning();

  return NextResponse.json({ product: inserted[0] }, { status: 201 });
}
