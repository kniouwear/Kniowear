import { db } from "@/db";
import { products, siteSettings } from "@/db/schema";
import { defaultProducts, brandDefaults } from "@/lib/brand";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import NewsletterForm from "@/components/NewsletterForm";
import Link from "next/link";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

type HomepageProduct = {
  id?: number;
  name: string;
  slug: string;
  description: string;
  price: number;
  category: string;
  imageUrl: string;
  featured?: boolean;
};

const collections = [
  {
    title: "Essentials",
    subtitle: "Core Wardrobe",
    image: "https://images.pexels.com/photos/6592254/pexels-photo-6592254.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    href: "/collections#Essentials",
  },
  {
    title: "Streetwear",
    subtitle: "Urban Edge",
    image: "https://images.pexels.com/photos/11317811/pexels-photo-11317811.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    href: "/collections#Streetwear",
  },
  {
    title: "Noir",
    subtitle: "Dark Elegance",
    image: "https://images.pexels.com/photos/16575981/pexels-photo-16575981.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    href: "/collections#Noir",
  },
  {
    title: "Avant-Garde",
    subtitle: "Beyond Boundaries",
    image: "https://images.pexels.com/photos/29221325/pexels-photo-29221325.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    href: "/collections#Avant-Garde",
  },
];

const lookbook = [
  {
    image: "https://images.pexels.com/photos/7871152/pexels-photo-7871152.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    title: "FW26 Campaign",
  },
  {
    image: "https://images.pexels.com/photos/7870748/pexels-photo-7870748.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    title: "Studio Session",
  },
  {
    image: "https://images.pexels.com/photos/8427591/pexels-photo-8427591.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    title: "Dark Edition",
  },
];

export default async function HomePage() {
  const [settingsRows, productRows] = await Promise.all([
    db.select().from(siteSettings),
    db.select().from(products).orderBy(desc(products.createdAt)),
  ]);

  const settings = Object.fromEntries(settingsRows.map((item) => [item.key, item.value]));
  const brand = {
    ...brandDefaults,
    ...settings,
  };

  const featuredProducts: HomepageProduct[] = (productRows.length > 0 ? productRows : defaultProducts)
    .filter((product) => ("featured" in product ? product.featured : true))
    .slice(0, 4);

  return (
    <>
      <Navbar />

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/7870748/pexels-photo-7870748.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=2000"
            alt="KNIO Fashion"
            className="w-full h-full object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black" />
        </div>

        <div className="relative z-10 text-center px-6 max-w-5xl mx-auto">
          <p className="text-[11px] font-light tracking-ultra uppercase text-white/50 mb-8 animate-fade-in">
            {brand.heroBadge}
          </p>
          <h1 className="text-[clamp(3.5rem,12vw,10rem)] font-bold tracking-ultra uppercase leading-[0.85] animate-fade-in-up">
            {brand.heroTitle}
          </h1>
          <p className="mt-8 text-lg md:text-xl font-extralight tracking-wider text-white/60 max-w-xl mx-auto animate-fade-in-up animation-delay-200">
            {brand.tagline}
          </p>
          <p className="mt-4 text-sm md:text-base text-white/40 max-w-2xl mx-auto animate-fade-in-up animation-delay-400">
            {brand.heroDescription}
          </p>
          <div className="mt-12 flex flex-col sm:flex-row items-center justify-center gap-4 animate-fade-in-up animation-delay-600">
            <Link
              href="/collections"
              className="bg-white text-black px-10 py-4 text-[13px] font-medium tracking-wide-custom uppercase hover:bg-white/90 transition-all duration-300"
            >
              Explore Collections
            </Link>
            <a
              href={`https://${brand.domain}`}
              target="_blank"
              rel="noopener noreferrer"
              className="border border-white/30 px-10 py-4 text-[13px] font-light tracking-wide-custom uppercase hover:bg-white/10 transition-all duration-300"
            >
              Visit Store
            </a>
          </div>
        </div>

        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-3">
          <span className="text-[10px] tracking-ultra uppercase text-white/30">Scroll</span>
          <div className="w-[1px] h-10 bg-white/10 relative overflow-hidden">
            <div className="w-full h-4 bg-white/50 animate-scroll-line" />
          </div>
        </div>
      </section>

      <div className="bg-white text-black py-4 overflow-hidden">
        <div className="animate-marquee whitespace-nowrap flex">
          {Array.from({ length: 10 }).map((_, i) => (
            <span key={i} className="mx-8 text-[13px] font-medium tracking-ultra uppercase">
              NEW COLLECTION AVAILABLE — SHOP AT {brand.domain.toUpperCase()} — FREE SHIPPING WORLDWIDE —
            </span>
          ))}
        </div>
      </div>

      <section className="py-32 px-6 lg:px-10 max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row items-start md:items-end justify-between mb-16">
          <div>
            <p className="text-[11px] font-light tracking-ultra uppercase text-white/40 mb-4">Discover</p>
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight">Featured Products</h2>
          </div>
          <Link href="/collections" className="mt-6 md:mt-0 text-[13px] font-light tracking-wide-custom uppercase text-white/50 hover:text-white transition-colors border-b border-white/20 hover:border-white pb-1">
            View All
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProducts.map((product) => (
            <div key={product.slug} className="group relative aspect-[3/4] overflow-hidden img-zoom">
              <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <p className="text-[10px] tracking-ultra uppercase text-white/50 mb-2">{product.category}</p>
                <h3 className="text-xl font-semibold tracking-wide">{product.name}</h3>
                <p className="text-sm text-white/50 mt-2">€{product.price}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="relative py-32 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/4862956/pexels-photo-4862956.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1600"
            alt="KNIO fabric texture"
            className="w-full h-full object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black via-black/90 to-black/70" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <p className="text-[11px] font-light tracking-ultra uppercase text-white/40 mb-6">Our Philosophy</p>
              <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight leading-[1.1]">
                Fashion is an
                <br />
                <span className="text-white/40">expression,</span>
                <br />
                not a trend.
              </h2>
              <p className="mt-8 text-base font-light text-white/50 leading-relaxed max-w-md">
                KNIO was born from the belief that clothing should speak for itself.
                Each piece is meticulously crafted to blend minimalism with bold expression,
                creating timeless garments that transcend seasons.
              </p>
              <Link href="/about" className="inline-flex items-center gap-3 mt-10 text-[13px] font-light tracking-wide-custom uppercase text-white/60 hover:text-white transition-colors group">
                <span>Read Our Story</span>
                <svg className="w-5 h-5 transform group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                </svg>
              </Link>
            </div>

            <div className="grid grid-cols-3 gap-8 text-center">
              {[
                { number: "26", label: "Collections" },
                { number: "50+", label: "Countries" },
                { number: "∞", label: "Possibilities" },
              ].map((stat) => (
                <div key={stat.label}>
                  <p className="text-4xl md:text-5xl font-bold">{stat.number}</p>
                  <p className="mt-2 text-[11px] tracking-ultra uppercase text-white/40">
                    {stat.label}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="py-32 px-6 lg:px-10 max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <p className="text-[11px] font-light tracking-ultra uppercase text-white/40 mb-4">Visual Diary</p>
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight">Lookbook</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {lookbook.map((item) => (
            <div key={item.title} className="group relative aspect-[16/10] overflow-hidden img-zoom cursor-pointer">
              <img src={item.image} alt={item.title} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-all duration-500" />
              <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                <p className="text-sm tracking-ultra uppercase font-light">{item.title}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="border-y border-white/10 py-16">
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 text-center">
            {[
              {
                icon: (
                  <svg className="w-6 h-6 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                  </svg>
                ),
                title: "Free Shipping",
                desc: "Worldwide delivery on all orders",
              },
              {
                icon: (
                  <svg className="w-6 h-6 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                  </svg>
                ),
                title: "Premium Quality",
                desc: "Handcrafted with finest materials",
              },
              {
                icon: (
                  <svg className="w-6 h-6 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                  </svg>
                ),
                title: "Easy Returns",
                desc: "30-day hassle-free return policy",
              },
            ].map((feature) => (
              <div key={feature.title} className="flex flex-col items-center">
                <div className="text-white/40 mb-4">{feature.icon}</div>
                <h3 className="text-sm font-medium tracking-wide-custom uppercase mb-2">{feature.title}</h3>
                <p className="text-sm text-white/40 font-light">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-32 px-6 lg:px-10">
        <div className="max-w-3xl mx-auto text-center">
          <p className="text-[11px] font-light tracking-ultra uppercase text-white/40 mb-4">Stay Connected</p>
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight mb-6">
            {brand.newsletterTitle}
          </h2>
          <p className="text-base font-light text-white/50 mb-10 max-w-md mx-auto">
            {brand.newsletterDescription}
          </p>
          <div className="flex justify-center">
            <NewsletterForm />
          </div>
        </div>
      </section>

      <Footer />
    </>
  );
}
