import { db } from "@/db";
import { products } from "@/db/schema";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import type { Metadata } from "next";
import { asc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Collections — KNIO",
  description: "Explore KNIO collections. From essentials to avant-garde, discover clothing that speaks for itself.",
};

const collectionDescriptions: Record<string, { subtitle: string; description: string; image: string }> = {
  Essentials: {
    subtitle: "Core Wardrobe — Timeless pieces",
    description:
      "The foundation of every wardrobe. Clean lines, premium fabrics, and versatile designs that work from dawn to dusk. Built to last, designed to impress.",
    image: "https://images.pexels.com/photos/6592254/pexels-photo-6592254.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
  },
  Streetwear: {
    subtitle: "Urban Edge — Bold statements",
    description:
      "Where street culture meets high fashion. Oversized fits, graphic prints, and unexpected textures. For those who own the sidewalk.",
    image: "https://images.pexels.com/photos/11317811/pexels-photo-11317811.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
  },
  Noir: {
    subtitle: "Dark Elegance — After dark",
    description:
      "Embrace the darkness. All-black everything with subtle details that reveal themselves in movement. For the ones who speak in whispers.",
    image: "https://images.pexels.com/photos/8427591/pexels-photo-8427591.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
  },
  "Avant-Garde": {
    subtitle: "Beyond Boundaries — Experimental",
    description:
      "Push the boundaries of convention. Architectural silhouettes, deconstructed forms, and bold experimentation. For the fearless.",
    image: "https://images.pexels.com/photos/29221325/pexels-photo-29221325.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
  },
};

export default async function CollectionsPage() {
  const productRows = await db.select().from(products).orderBy(asc(products.category));

  const grouped = productRows.reduce<Record<string, typeof productRows>>((acc, product) => {
    const key = product.category || "Other";
    if (!acc[key]) acc[key] = [];
    acc[key].push(product);
    return acc;
  }, {});

  const categories = Object.keys(collectionDescriptions);
  const activeCategories = categories.filter((category) => grouped[category]?.length);
  const displayCategories = activeCategories.length ? activeCategories : categories;

  return (
    <>
      <Navbar />

      <section className="relative pt-32 pb-20 px-6 lg:px-10">
        <div className="max-w-7xl mx-auto">
          <p className="text-[11px] font-light tracking-ultra uppercase text-white/40 mb-4">FW26</p>
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold tracking-tight">Collections</h1>
          <p className="mt-6 text-lg font-light text-white/50 max-w-lg">
            Four distinct worlds, one shared vision. Explore the full range of KNIO.
          </p>
        </div>
      </section>

      {displayCategories.map((category, index) => {
        const info = collectionDescriptions[category];
        const items = grouped[category] ?? [];
        const productsToShow = items.length > 0 ? items : [];

        return (
          <section key={category} id={category} className={`py-24 px-6 lg:px-10 ${index % 2 === 0 ? "" : "bg-white/[0.02]"}`}>
            <div className="max-w-7xl mx-auto">
              <div className={`grid grid-cols-1 lg:grid-cols-2 gap-16 items-center ${index % 2 === 1 ? "lg:flex-row-reverse" : ""}`}>
                <div className={`${index % 2 === 1 ? "lg:order-2" : ""}`}>
                  <div className="relative aspect-[3/4] overflow-hidden img-zoom">
                    <img src={info.image} alt={category} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
                  </div>
                </div>

                <div className={`${index % 2 === 1 ? "lg:order-1" : ""}`}>
                  <p className="text-[11px] font-light tracking-ultra uppercase text-white/40 mb-4">{info.subtitle}</p>
                  <h2 className="text-4xl md:text-6xl font-bold tracking-tight mb-6">{category}</h2>
                  <p className="text-base font-light text-white/50 leading-relaxed mb-10 max-w-md">{info.description}</p>

                  <div className="grid grid-cols-2 gap-4 mb-8">
                    {productsToShow.slice(0, 2).map((product) => (
                      <div key={product.id} className="group cursor-pointer">
                        <div className="aspect-[3/4] overflow-hidden mb-3 img-zoom">
                          <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover" />
                        </div>
                        <p className="text-sm font-medium">{product.name}</p>
                        <p className="text-sm text-white/40">€{product.price}</p>
                      </div>
                    ))}
                    {productsToShow.length === 0 ? (
                      <div className="col-span-2 border border-white/10 p-6 text-sm text-white/40">
                        Products for this collection will appear here once added in the admin dashboard.
                      </div>
                    ) : null}
                  </div>

                  <a href="https://kniowear.com" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-3 text-[13px] font-light tracking-wide-custom uppercase text-white/60 hover:text-white transition-colors group">
                    <span>Shop {category}</span>
                    <svg className="w-5 h-5 transform group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                    </svg>
                  </a>
                </div>
              </div>
            </div>
          </section>
        );
      })}

      <section className="py-32 px-6 text-center">
        <div className="max-w-2xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight mb-6">Ready to redefine your style?</h2>
          <p className="text-base font-light text-white/50 mb-10">Visit our online store to explore the full catalog and find your perfect pieces.</p>
          <a href="https://kniowear.com" target="_blank" rel="noopener noreferrer" className="inline-block bg-white text-black px-12 py-4 text-[13px] font-medium tracking-wide-custom uppercase hover:bg-white/90 transition-colors duration-300">Shop at kniowear.com</a>
        </div>
      </section>

      <Footer />
    </>
  );
}
