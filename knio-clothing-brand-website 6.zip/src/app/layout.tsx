import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "KNIO — Modern Fashion Brand",
  description: "Discover KNIO — where minimalism meets bold fashion. Premium clothing designed for the modern individual. Shop the latest collections at kniowear.com",
  keywords: ["KNIO", "fashion", "clothing", "streetwear", "luxury", "kniowear"],
  openGraph: {
    title: "KNIO — Modern Fashion Brand",
    description: "Where minimalism meets bold fashion",
    url: "https://kniowear.com",
    siteName: "KNIO",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-black text-white antialiased font-sans selection:bg-white selection:text-black">
        {children}
      </body>
    </html>
  );
}
