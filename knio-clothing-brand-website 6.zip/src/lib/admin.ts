import { cookies } from "next/headers";
import { redirect } from "next/navigation";

export const ADMIN_COOKIE = "knio_admin";
export const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "knio-admin";

export async function isAdminAuthenticated() {
  return (await cookies()).get(ADMIN_COOKIE)?.value === "1";
}

export async function requireAdmin() {
  if (!(await isAdminAuthenticated())) {
    redirect("/admin/login");
  }
}
