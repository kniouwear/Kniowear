export const brandDefaults = {
  name: "KNIO",
  domain: "kniowear.com",
  tagline: "Where minimalism meets bold fashion",
  heroBadge: "Fall / Winter 2026",
  heroTitle: "KNIO",
  heroDescription:
    "Premium clothing designed for the modern individual. Discover elevated essentials, streetwear, noir tailoring, and avant-garde silhouettes.",
  newsletterTitle: "Join the KNIO Family",
  newsletterDescription:
    "Be the first to know about new collections, exclusive releases, and behind-the-scenes content.",
};

export const defaultProducts = [
  {
    name: "Essential Tee",
    slug: "essential-tee",
    description: "A refined everyday tee crafted from premium cotton.",
    price: 65,
    category: "Essentials",
    imageUrl:
      "https://images.pexels.com/photos/7760558/pexels-photo-7760558.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=900",
    featured: true,
  },
  {
    name: "Oversized Hoodie",
    slug: "oversized-hoodie",
    description: "A heavy-weight silhouette made for modern streetwear layering.",
    price: 95,
    category: "Streetwear",
    imageUrl:
      "https://images.pexels.com/photos/2081435/pexels-photo-2081435.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=900",
    featured: true,
  },
  {
    name: "Shadow Jacket",
    slug: "shadow-jacket",
    description: "A sharp black layer with a clean architectural profile.",
    price: 210,
    category: "Noir",
    imageUrl:
      "https://images.pexels.com/photos/38023947/pexels-photo-38023947.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=900",
    featured: true,
  },
  {
    name: "Decon Coat",
    slug: "decon-coat",
    description: "Experimental outerwear with sculptural lines and bold proportions.",
    price: 320,
    category: "Avant-Garde",
    imageUrl:
      "https://images.pexels.com/photos/10596845/pexels-photo-10596845.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=900",
    featured: true,
  },
];
